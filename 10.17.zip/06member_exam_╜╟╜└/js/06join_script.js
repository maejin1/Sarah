function validateForm(){      //key : 정규표현식, form에서 name~~
  const f = document.member;       //member form 을 말함
  const reg_exp=new RegExp("^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$");
  const match=reg_exp.exec(f.id.value);         //<---id값을 가져올 수는 없음...!! form에서 id의 값 인데 이게 name을 말하는 거래~~!!!

                                   //exec (데이터값을 갖고온게 이 것과 맞는지 체크하는 함수!!)
// new : 객체 받아오는거... (RegExp가 객체..)

// 정규표현식)
// (?=.*[a-zA-Z])      ---> a~z까지 다들어가야하고
//(?=.*[!@#$%^*+=-])  ----> 특수문자 들어가야하고
//(?=.*[0-9])         ---> 0~9 숫자 들어가야하고
//{6,10}$              ---> 6자리~10자리??
  if(match==null){        //---> null :값이 없다 (여기서는 정규표현식에서 갖고온것과 맞는것이 없을경우~~)
     alert("6~10자의 영문자, 숫자, 특수기호 혼합해서 사용할 수 있습니다");
     return false;           //a로 가는 거 차단.. (중단의 개념...그대로 있어라..)
  }


const x =document.forms["member"]["name"].value;  //member form에 name의 값을 가져와라?
if (x==null || x=="")                //---> 값이 없을 경우 (하나만 쓰면 안될때도 있어서..)
{
  alert("이름을 입력하세요.");
  return false;
}

const reg_exp1=new RegExp("^(?=.*[a-zA-Z])(?=.*[0-9]).{4,8}$");
const match1 = reg_exp1.exec(f.pass.value);   //pass란? 비밀번호의 name~~~~
if(match1==null){             //프로그램 더 배울수록 null에대해 깊이 알아야 한대...
                              //
  alert("숫자와 영문자 조합으로 4~8자리를 사용해야 합니다");
  return false;
}

const x1 = document.forms["member"]["pass"].value;
const x2= document.forms["member"]["pass_confirm"].value;

if (x1 != x2)    //!는 not이란 뜻~~
{
alert("비밀번호가 일치하지 않습니다."); //--> 참이면 그냥 빠져나감~~
return false;          
}

const x3=document.forms["member"]["email"].value;
if(x4==null || x4=="")
{
  alert("Email을 입력하세요");
  return false;
}

}