﻿$(function(){
   const numAc = $("article").size();   //----> article의 개수~~
  const widSec = 200*numAc;   //---> 200*200
  const widTotal = widSec + 600;    //---> section안에 20개가 다 들어가야 함
                                    
  $("section").width(widTotal);  // section에다가 width값을 widTotal로 설정해라 (4600으로)
  $("body").height(widSec); //스크롤 하나만큼 할때 200*200만큼 늘어나야 하므로...
  $(window).on("scroll",function(){
    const scroll = $(this).scrollTop();
    $("section").stop().animate({"left":-scroll},600);
  });


  $("article h2").on("click", function(e){
    e.preventDefault();
    const index = $(this).parent().index();
    const src = $(this).children("a").attr("href");
    const posAc = 200*index;

    $("article").removeClass("on");
    $(this).parent().addClass("on");
    $("article p img").attr({"src":""});      //---> 초기화
    $(this).siblings("p").children("img").attr({"src":src});
    $("html,body").scrollTop(posAc);
  });
  $("span").on("click", function(){
    $("article").removeClass("on");
  })


  $("#navi li").on("click",function(){
    const i = $(this).index();
    const posNavi = 1000*i;            //5개씩 나오도록~~~~
    $("#navi li, article").removeClass();
    $(this).addClass("on");
    $("html,body").scrollTop(posNavi);
  })

});















