// ------------------제이쿼리가 아닌 자바스크립트로 만들기 ----------------------------------
// * point : querySelector / addEventListener

const header = document.querySelector("#page-header");
function scrollFunc(){
  if (pageYOffset >=90){             //우리가 높이를 70정도까지 해줬으므로 넉넉하게 90이상으로 논것...
                                     // =>  pageYOffset : 문서가 수직으로 얼마나 스크롤됐는지 픽셀단위로 반환하는 함수....
    header.classList.add('sticky');      //classList  ---> 클래스를 인식함
  } else {
    header.classList.remove('sticky');
  }

}
  //addListener  : 이벤트 감지하는것!

  window.addEventListener("scroll",scrollFunc);
  // addEventListener는 함수쓸때 ""안씀~~ (listener만~)
