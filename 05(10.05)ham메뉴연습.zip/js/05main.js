$(function(){
 		
	// ---------------옆으로 미는듯한 효과--------------------------------
		$(function(){
			$(".hamburger").click(function(){
				$("body").animate({marginLeft:"200px"}, 300);
				$(".menu").animate({marginLeft:"200px"}, 300);
				$(".cross").show();
				$(".hamburger").hide();
			})
		})
	
// ------------------------------------------------------------------
     // 서브메뉴부분
     $(".menu >ul >li> a").click(function(){
     if($(this).next().is(":visible"))
      {
       $(this).next().stop().slideUp(500);
       $(this).children("img").attr("src","img/arrow-down.png");
      }else{
        $(".sub").stop().slideUp(500);
$(".menu >ul >li> a").children("img").attr("src","img/arrow-down.png"); 
    $(this).next().stop().slideDown(500);
    $(this).find("img").attr("src","img/arrow-up.png");        
      }

     });

     // 메뉴종료
     $( ".cross" ).click(function() {
        $(".menu").animate({marginLeft:"0"}, 300);
		$("body").animate({marginLeft:"0"}, 300);
				 $(".cross").hide();
		     $( ".hamburger" ).show();
      });

});