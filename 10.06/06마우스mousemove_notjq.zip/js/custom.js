﻿$(document).ready(function(){        //ready??	
   
let imgs='';   //img추가

for(let i=0; i<10; i++){
  imgs+="<img src='img/pic"+i+".jpg'>"  //img 10장 뽑는것
}

$("section").html(imgs);        //section에 img가 있어야 하니까
$("body").on("mousemove",function(e){           //마우스 움직일때 mousemove 이벤트~~   
  const wid = $(window).width();                //x좌표 뽑을때는 function(e)해서 e.pageX이렇게 해야~~
  const posX = e.pageX;    // pageX---> x좌표 뽑는것
  const percent = Math.floor((posX/wid)*10);   //Math라는 객체/에 floor함수(=소수점 이하 버리는거)
  $("section>img").hide();                     //animation할때 ★floor함수 굉장히 많이씀~~!
  $("section>img").eq(percent).show();
})
});















